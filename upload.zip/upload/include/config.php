<?php

$maxFileSize = 31457280;
$fileSizeLimitText = "30MB Max limit upload.";
$titleHeader = "vido";
$titleHeaderTiny = ".my.id";
$emailReport = "vidovideohost@gmail.com";
?>