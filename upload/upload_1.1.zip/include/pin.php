<?php

$adminPIN = '$argon2i$v=19$m=65536,t=4,p=1$YkIzN3hocjhBL21NbHN3Qg$pgHuizxeyceUQm/CDQ8TxMRk1XvmVHTAUBGad52sCNo';

?>