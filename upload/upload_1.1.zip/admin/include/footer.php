<div class="bg-gray-800 text-white text-center py-6 mt-auto">
    <div class="max-w-7xl mx-auto px-4">
        <p class="text-sm md:text-base">© Vido Video Script 1.1. All rights reserved.</p>
        <p class="text-xs mt-2">Made with ❤️ by GWolf Lab</p>
    </div>
</div>
